﻿# Student Assignment Workspace

Минимальная платформа для ученика:
- получает задания из основного проекта через API;
- адаптирует задания под профиль ученика;
- показывает только релевантные задания для выполнения.

## Быстрый запуск

```bash
npm start
```

Открыть: `http://localhost:3000`

Если в интерфейсе появляется `Server error`, остановите старый процесс и запустите сервер заново:

```bash
npm start
```

## Основной сценарий

1. Основной проект отправляет задания в платформу через `POST /api/external-content`.
2. Ученик открывает платформу.
3. Платформа запрашивает `GET /api/adapted-feed` и возвращает адаптированные задания.
4. Ученик открывает задание на отдельной странице `task.html`.
5. На странице задания ученик проходит этапы по шагам (`Шаг 1`, `Шаг 2`, ...).
6. После последнего шага отправляет форму на проверку через `POST /api/submissions`.

## API

### Профили учеников

- `GET /api/profiles`

### Импорт заданий из основного проекта

- `POST /api/external-content`
- Header: `X-Admin-Token: demo-admin-token`
- Body (JSON):

```json
{
  "externalId": "main-lesson-1001",
  "title": "Видеоурок по математике",
  "subject": "Математика",
  "type": "video",
  "teacher": "Учитель из основного проекта",
  "instructions": "Посмотри видео и выполни задания.",
  "language": "ru",
  "translations": ["ru", "kz"],
  "durationMinutes": 20,
  "dueDate": "2026-03-01"
}
```

### Адаптированная лента для ученика

- `GET /api/adapted-feed?studentId=student-001`

### Одно адаптированное задание для страницы выполнения

- `GET /api/adapted-task?studentId=student-001&taskId=task-test-001`

Дополнительные фильтры от основного проекта:
- `externalId=<id>`
- `externalIds=<id1,id2>`
- `type=assignment|video`
- `subject=<subject>`

Пример:

`GET /api/adapted-feed?studentId=student-001&externalId=main-lesson-1001`

### Отправка решения ученика на проверку

- `POST /api/submissions`
- Body (JSON):

```json
{
  "studentId": "student-001",
  "taskId": "task-test-001",
  "answers": [
    { "questionId": "q1", "answer": "Ответ на первый вопрос" },
    { "questionId": "q2", "answer": "Ответ на второй вопрос" },
    { "questionId": "q3", "answer": "Ответ на третий вопрос" }
  ]
}
```

Ответ:
- `status: pending_review` - решение отправлено преподавателю и ожидает проверки.

### Получение отправленных решений

- `GET /api/submissions?studentId=student-001`
- `GET /api/submissions?studentId=student-001&taskId=task-test-001`

## Структура

- `server.js` - API и раздача фронтенда
- `adaptation.js` - логика адаптации контента
- `data/profiles.json` - профили учеников
- `data/external-content.json` - задания из основного проекта
- `data/submissions.json` - отправленные решения учеников
- `public/index.html` - интерфейс ученика
- `public/app.js` - клиентская логика
- `public/task.html` - отдельная страница выполнения задания
- `public/task.js` - пошаговая логика прохождения задания
- `public/styles.css` - стили интерфейса
