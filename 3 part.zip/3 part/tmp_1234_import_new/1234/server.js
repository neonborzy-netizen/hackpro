﻿const http = require("http");
const fs = require("fs");
const path = require("path");
const { URL } = require("url");
const { adaptFeed } = require("./adaptation");

const PORT = process.env.PORT || 3000;
const PUBLIC_DIR = path.join(__dirname, "public");
const DATA_DIR = path.join(__dirname, "data");
const CONTENT_PATH = path.join(DATA_DIR, "external-content.json");
const PROFILES_PATH = path.join(DATA_DIR, "profiles.json");
const SUBMISSIONS_PATH = path.join(DATA_DIR, "submissions.json");
const ADMIN_TOKEN = process.env.EXTERNAL_ADMIN_TOKEN || "demo-admin-token";

const CONTENT_TYPE = {
  ".html": "text/html; charset=utf-8",
  ".css": "text/css; charset=utf-8",
  ".js": "application/javascript; charset=utf-8",
  ".json": "application/json; charset=utf-8",
  ".svg": "image/svg+xml"
};

function readJson(filePath) {
  const raw = fs.readFileSync(filePath, "utf-8").replace(/^\uFEFF/, "");
  return JSON.parse(raw);
}

function writeJson(filePath, value) {
  fs.writeFileSync(filePath, JSON.stringify(value, null, 2), "utf-8");
}

function ensureJsonArrayFile(filePath) {
  if (!fs.existsSync(filePath)) {
    writeJson(filePath, []);
  }
}

function sendJson(res, statusCode, payload) {
  res.writeHead(statusCode, {
    "Content-Type": "application/json; charset=utf-8",
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Headers": "Content-Type, X-Admin-Token",
    "Access-Control-Allow-Methods": "GET, POST, OPTIONS"
  });

  res.end(JSON.stringify(payload));
}

function readBody(req) {
  return new Promise((resolve, reject) => {
    let data = "";

    req.on("data", (chunk) => {
      data += chunk;
    });

    req.on("end", () => {
      if (!data) {
        resolve({});
        return;
      }

      try {
        resolve(JSON.parse(data));
      } catch (err) {
        reject(new Error("Invalid JSON body"));
      }
    });

    req.on("error", reject);
  });
}

function serveStatic(res, pathname) {
  const safePath = pathname === "/" ? "/index.html" : pathname;
  const requestedPath = path.normalize(path.join(PUBLIC_DIR, safePath));

  if (!requestedPath.startsWith(PUBLIC_DIR)) {
    sendJson(res, 403, { error: "Forbidden path" });
    return;
  }

  if (!fs.existsSync(requestedPath) || fs.statSync(requestedPath).isDirectory()) {
    sendJson(res, 404, { error: "File not found" });
    return;
  }

  const extension = path.extname(requestedPath).toLowerCase();
  const type = CONTENT_TYPE[extension] || "application/octet-stream";
  const fileContent = fs.readFileSync(requestedPath);

  res.writeHead(200, { "Content-Type": type });
  res.end(fileContent);
}

function getStudentById(studentId) {
  const profiles = readJson(PROFILES_PATH);
  return profiles.find((item) => item.id === studentId);
}

function getTaskById(taskId) {
  const tasks = readJson(CONTENT_PATH);
  return tasks.find((task) => task.id === taskId || task.externalId === taskId);
}

function normalizeQuestion(question, index) {
  const prompt = String(question?.prompt || question?.text || "").trim();
  if (!prompt) return null;

  return {
    id: String(question.id || `q${index + 1}`),
    prompt,
    placeholder: String(question.placeholder || "Введите ответ").trim(),
    required: question.required !== false
  };
}

function normalizeQuestions(sourceQuestions, fallbackInstruction) {
  const questions = (Array.isArray(sourceQuestions) ? sourceQuestions : [])
    .map((question, index) => normalizeQuestion(question, index))
    .filter(Boolean);

  if (questions.length) return questions;

  const fallback = String(fallbackInstruction || "Опиши решение задания.").trim();
  if (!fallback) return [];

  return [
    {
      id: "q1",
      prompt: fallback,
      placeholder: "Введите ответ",
      required: true
    }
  ];
}

function mapIncomingExternalTask(payload) {
  const now = Date.now().toString(36);
  const instructions = payload.instructions || "Open the material and complete the assignment.";

  return {
    id: `task-${now}`,
    externalId: payload.externalId || `ext-${now}`,
    type: payload.type || "assignment",
    subject: payload.subject || "General",
    teacher: payload.teacher || "Not set",
    title: payload.title || "New material",
    instructions,
    questions: normalizeQuestions(payload.questions, instructions),
    language: payload.language || "ru",
    translations: Array.isArray(payload.translations) ? payload.translations : ["ru", "kz"],
    durationMinutes: Number(payload.durationMinutes) || 20,
    dueDate: payload.dueDate || null,
    sourceSystem: payload.sourceSystem || "main-project",
    createdAt: new Date().toISOString()
  };
}

function parseCsvParam(value) {
  if (!value) return [];

  return value
    .split(",")
    .map((part) => part.trim())
    .filter(Boolean);
}

function filterTasksBySelection(tasks, searchParams) {
  const explicitIds = [
    ...parseCsvParam(searchParams.get("externalId")),
    ...parseCsvParam(searchParams.get("externalIds"))
  ];
  const selectedType = searchParams.get("type");
  const selectedSubject = searchParams.get("subject");
  let filtered = tasks;

  if (explicitIds.length) {
    const allowedIds = new Set(explicitIds);
    filtered = filtered.filter((task) => allowedIds.has(task.externalId) || allowedIds.has(task.id));
  }

  if (selectedType) {
    filtered = filtered.filter((task) => task.type === selectedType);
  }

  if (selectedSubject) {
    const targetSubject = selectedSubject.toLowerCase();
    filtered = filtered.filter((task) => String(task.subject || "").toLowerCase() === targetSubject);
  }

  return {
    filtered,
    selection: {
      externalIds: explicitIds,
      type: selectedType || null,
      subject: selectedSubject || null
    }
  };
}

function buildAdaptedResponse(studentId, searchParams) {
  const profile = getStudentById(studentId);
  if (!profile) {
    return { error: { code: 404, message: "Student profile not found" } };
  }

  const tasks = readJson(CONTENT_PATH);
  const { filtered, selection } = filterTasksBySelection(tasks, searchParams);
  const response = adaptFeed(filtered, profile);
  response.selection = {
    ...selection,
    sourceTaskCount: tasks.length,
    matchedTaskCount: filtered.length
  };

  return { response };
}

function normalizeIncomingAnswers(payload, task) {
  const taskQuestions = normalizeQuestions(task.questions, task.instructions);

  let incoming = [];
  if (Array.isArray(payload.answers)) {
    incoming = payload.answers;
  } else if (payload.answer) {
    incoming = [
      {
        questionId: taskQuestions[0]?.id || "q1",
        answer: payload.answer
      }
    ];
  }

  const answerById = new Map(
    incoming
      .map((item) => {
        const questionId = String(item?.questionId || "").trim();
        const answer = String(item?.answer || "").trim();
        if (!questionId) return null;
        return [questionId, answer];
      })
      .filter(Boolean)
  );

  const answers = taskQuestions.map((question) => ({
    questionId: question.id,
    answer: String(answerById.get(question.id) || "").trim()
  }));

  const hasMissingRequired = taskQuestions.some((question) => {
    if (!question.required) return false;
    const answer = answers.find((item) => item.questionId === question.id);
    return !answer || answer.answer.length < 2;
  });

  return {
    answers,
    hasMissingRequired,
    summary: answers.map((item) => `[${item.questionId}] ${item.answer}`).join("\n")
  };
}

function mapSubmission(payload) {
  const now = new Date();
  const ts = now.getTime().toString(36);

  return {
    id: `submission-${ts}`,
    studentId: payload.studentId,
    taskId: payload.taskId,
    answers: payload.answers,
    answer: payload.summary,
    status: "pending_review",
    submittedAt: now.toISOString()
  };
}

async function handleApi(req, res, url) {
  const pathname = url.pathname;

  if (req.method === "OPTIONS") {
    res.writeHead(204, {
      "Access-Control-Allow-Origin": "*",
      "Access-Control-Allow-Headers": "Content-Type, X-Admin-Token",
      "Access-Control-Allow-Methods": "GET, POST, OPTIONS"
    });
    res.end();
    return true;
  }

  if (req.method === "GET" && pathname === "/api/profiles") {
    const profiles = readJson(PROFILES_PATH);
    sendJson(res, 200, profiles);
    return true;
  }

  if (req.method === "GET" && pathname === "/api/submissions") {
    const studentId = url.searchParams.get("studentId");
    if (!studentId) {
      sendJson(res, 400, { error: "studentId query param is required" });
      return true;
    }

    if (!getStudentById(studentId)) {
      sendJson(res, 404, { error: "Student profile not found" });
      return true;
    }

    ensureJsonArrayFile(SUBMISSIONS_PATH);
    const taskId = url.searchParams.get("taskId");
    const allSubmissions = readJson(SUBMISSIONS_PATH);
    const filtered = allSubmissions.filter((submission) => {
      if (submission.studentId !== studentId) return false;
      if (!taskId) return true;
      return submission.taskId === taskId;
    });

    sendJson(res, 200, filtered);
    return true;
  }

  if (req.method === "GET" && pathname === "/api/adapted-task") {
    const studentId = url.searchParams.get("studentId");
    const taskId = url.searchParams.get("taskId");

    if (!studentId || !taskId) {
      sendJson(res, 400, { error: "studentId and taskId query params are required" });
      return true;
    }

    const built = buildAdaptedResponse(studentId, url.searchParams);
    if (built.error) {
      sendJson(res, built.error.code, { error: built.error.message });
      return true;
    }

    const item = built.response.items.find(
      (task) => task.id === taskId || task.sourceTaskId === taskId
    );

    if (!item) {
      sendJson(res, 404, { error: "Task not found in adapted feed" });
      return true;
    }

    sendJson(res, 200, {
      student: built.response.student,
      uiPreset: built.response.uiPreset,
      generatedAt: built.response.generatedAt,
      item
    });
    return true;
  }

  if (req.method === "POST" && pathname === "/api/external-content") {
    const incomingToken = req.headers["x-admin-token"];
    if (incomingToken !== ADMIN_TOKEN) {
      sendJson(res, 401, { error: "Invalid admin token" });
      return true;
    }

    try {
      const payload = await readBody(req);
      const existing = readJson(CONTENT_PATH);
      const mappedTask = mapIncomingExternalTask(payload);
      const updated = [mappedTask, ...existing];
      writeJson(CONTENT_PATH, updated);
      sendJson(res, 201, { message: "Task imported", task: mappedTask });
      return true;
    } catch (err) {
      sendJson(res, 400, { error: err.message });
      return true;
    }
  }

  if (req.method === "POST" && pathname === "/api/submissions") {
    try {
      const payload = await readBody(req);
      const studentId = String(payload.studentId || "").trim();
      const taskId = String(payload.taskId || "").trim();

      if (!studentId || !taskId) {
        sendJson(res, 400, { error: "studentId and taskId are required" });
        return true;
      }

      if (!getStudentById(studentId)) {
        sendJson(res, 404, { error: "Student profile not found" });
        return true;
      }

      const task = getTaskById(taskId);
      if (!task) {
        sendJson(res, 404, { error: "Task not found" });
        return true;
      }

      const normalized = normalizeIncomingAnswers(payload, task);
      if (normalized.hasMissingRequired) {
        sendJson(res, 400, { error: "Заполните все обязательные поля ответа" });
        return true;
      }

      ensureJsonArrayFile(SUBMISSIONS_PATH);
      const newSubmission = mapSubmission({
        studentId,
        taskId: task.id,
        answers: normalized.answers,
        summary: normalized.summary
      });

      const existing = readJson(SUBMISSIONS_PATH);
      const updated = [newSubmission, ...existing];
      writeJson(SUBMISSIONS_PATH, updated);

      sendJson(res, 201, {
        message: "Solution submitted for review",
        submission: {
          id: newSubmission.id,
          studentId: newSubmission.studentId,
          taskId: newSubmission.taskId,
          answers: newSubmission.answers,
          status: newSubmission.status,
          submittedAt: newSubmission.submittedAt
        }
      });
      return true;
    } catch (err) {
      sendJson(res, 400, { error: err.message });
      return true;
    }
  }

  if (req.method === "GET" && pathname === "/api/adapted-feed") {
    const studentId = url.searchParams.get("studentId");
    if (!studentId) {
      sendJson(res, 400, { error: "studentId query param is required" });
      return true;
    }

    const built = buildAdaptedResponse(studentId, url.searchParams);
    if (built.error) {
      sendJson(res, built.error.code, { error: built.error.message });
      return true;
    }

    sendJson(res, 200, built.response);
    return true;
  }

  return false;
}

const server = http.createServer(async (req, res) => {
  try {
    const url = new URL(req.url, `http://${req.headers.host}`);
    const isApi = url.pathname.startsWith("/api/");

    if (isApi) {
      const handled = await handleApi(req, res, url);
      if (!handled) sendJson(res, 404, { error: "API route not found" });
      return;
    }

    serveStatic(res, url.pathname);
  } catch (err) {
    sendJson(res, 500, { error: "Server error", details: err.message });
  }
});

ensureJsonArrayFile(SUBMISSIONS_PATH);

server.listen(PORT, () => {
  console.log(`Student workspace running at http://localhost:${PORT}`);
});
