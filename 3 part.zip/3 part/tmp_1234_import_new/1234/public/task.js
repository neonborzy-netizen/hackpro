const state = {
  defaultStudentId: "student-001",
  studentId: null,
  taskId: null,
  task: null,
  questions: [],
  answers: [],
  currentStep: 0
};

const taskPageTitle = document.getElementById("taskPageTitle");
const taskPageMeta = document.getElementById("taskPageMeta");
const taskPageInstruction = document.getElementById("taskPageInstruction");
const taskStepBadge = document.getElementById("taskStepBadge");
const questionPrompt = document.getElementById("questionPrompt");
const questionInput = document.getElementById("questionInput");
const prevStepBtn = document.getElementById("prevStepBtn");
const nextStepBtn = document.getElementById("nextStepBtn");
const submitStepBtn = document.getElementById("submitStepBtn");
const stepForm = document.getElementById("stepForm");
const stepStatus = document.getElementById("stepStatus");
const backToList = document.getElementById("backToList");

function escapeHtml(value) {
  return String(value)
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#39;");
}

function setStatus(text, toneClass = "status-none") {
  stepStatus.textContent = text;
  stepStatus.classList.remove("status-none", "status-pending", "status-error");
  stepStatus.classList.add(toneClass);
}

function normalizeBackLink(value) {
  if (!value) {
    return `/?studentId=${encodeURIComponent(state.studentId)}`;
  }

  if (value.startsWith("?")) return `/${value}`;
  if (value.startsWith("/")) return value;
  return `/?studentId=${encodeURIComponent(state.studentId)}`;
}

function applyDynamicUi(uiPreset) {
  document.documentElement.style.setProperty("--font-scale", uiPreset.fontScale);
  document.body.style.fontSize = `${16 * uiPreset.fontScale}px`;

  if (uiPreset.highContrast) {
    document.documentElement.classList.add("high-contrast");
  } else {
    document.documentElement.classList.remove("high-contrast");
  }

  if (uiPreset.largeControls) {
    document.documentElement.classList.add("large-controls");
  } else {
    document.documentElement.classList.remove("large-controls");
  }
}

async function fetchJson(url, options = {}) {
  const response = await fetch(url, options);

  if (!response.ok) {
    let message = "Request failed";
    const rawBody = await response.text();

    if (rawBody) {
      try {
        const json = JSON.parse(rawBody);
        message = json.error || message;
      } catch {
        message = rawBody;
      }
    }

    throw new Error(message);
  }

  return response.json();
}

function saveCurrentStepAnswer() {
  const question = state.questions[state.currentStep];
  if (!question) return;

  state.answers[state.currentStep] = {
    questionId: question.id,
    answer: String(questionInput.value || "").trim()
  };
}

function isRequiredAnswerValid(answerItem, question) {
  if (!question.required) return true;
  return Boolean(answerItem && answerItem.answer && answerItem.answer.trim().length >= 2);
}

function validateCurrentStep() {
  const question = state.questions[state.currentStep];
  const answer = state.answers[state.currentStep];

  if (!isRequiredAnswerValid(answer, question)) {
    setStatus("Заполните ответ текущего шага (минимум 2 символа).", "status-error");
    return false;
  }

  setStatus("", "status-none");
  return true;
}

function firstInvalidStepIndex() {
  return state.questions.findIndex((question, index) => {
    const answer = state.answers[index];
    return !isRequiredAnswerValid(answer, question);
  });
}

function renderStep() {
  if (!state.questions.length) return;

  const stepNumber = state.currentStep + 1;
  const total = state.questions.length;
  const question = state.questions[state.currentStep];
  const answer = state.answers[state.currentStep];

  taskStepBadge.textContent = `Шаг ${stepNumber} из ${total}`;
  questionPrompt.textContent = `Вопрос ${stepNumber}. ${question.prompt}`;
  questionInput.placeholder = question.placeholder || "Введите ответ";
  questionInput.value = answer?.answer || "";
  questionInput.required = question.required !== false;

  prevStepBtn.disabled = state.currentStep === 0;
  nextStepBtn.hidden = state.currentStep === total - 1;
  submitStepBtn.hidden = state.currentStep !== total - 1;
}

function initTaskState(task, submission) {
  state.task = task;
  state.questions = Array.isArray(task.questions) && task.questions.length
    ? task.questions
    : [{ id: "q1", prompt: task.instructionText || "Ответь на задание", required: true }];

  const savedAnswersMap = new Map(
    Array.isArray(submission?.answers)
      ? submission.answers.map((item) => [item.questionId, String(item.answer || "")])
      : []
  );

  state.answers = state.questions.map((question) => ({
    questionId: question.id,
    answer: savedAnswersMap.get(question.id) || ""
  }));
  state.currentStep = 0;
}

async function loadTaskData() {
  const params = new URLSearchParams(window.location.search);
  state.studentId = params.get("studentId") || state.defaultStudentId;
  state.taskId = params.get("taskId");

  if (!state.taskId) {
    throw new Error("Не указан taskId в адресе страницы");
  }

  backToList.href = normalizeBackLink(params.get("back"));

  const taskResponse = await fetchJson(
    `/api/adapted-task?studentId=${encodeURIComponent(state.studentId)}&taskId=${encodeURIComponent(
      state.taskId
    )}`
  );

  const submissions = await fetchJson(
    `/api/submissions?studentId=${encodeURIComponent(state.studentId)}&taskId=${encodeURIComponent(
      taskResponse.item.id
    )}`
  );
  const latestSubmission = Array.isArray(submissions) && submissions.length ? submissions[0] : null;

  taskPageTitle.textContent = taskResponse.item.title;
  taskPageMeta.textContent = `${taskResponse.item.subject} | ${taskResponse.item.teacher}`;
  taskPageInstruction.textContent = taskResponse.item.instructionText;
  applyDynamicUi(taskResponse.uiPreset);

  initTaskState(taskResponse.item, latestSubmission);
  renderStep();
}

prevStepBtn.addEventListener("click", () => {
  saveCurrentStepAnswer();
  if (state.currentStep > 0) {
    state.currentStep -= 1;
    renderStep();
    setStatus("", "status-none");
  }
});

nextStepBtn.addEventListener("click", () => {
  saveCurrentStepAnswer();
  if (!validateCurrentStep()) return;

  if (state.currentStep < state.questions.length - 1) {
    state.currentStep += 1;
    renderStep();
  }
});

stepForm.addEventListener("submit", async (event) => {
  event.preventDefault();
  saveCurrentStepAnswer();

  const invalidIndex = firstInvalidStepIndex();
  if (invalidIndex !== -1) {
    state.currentStep = invalidIndex;
    renderStep();
    setStatus("Заполните все этапы задания перед отправкой.", "status-error");
    return;
  }

  submitStepBtn.disabled = true;

  try {
    const payload = {
      studentId: state.studentId,
      taskId: state.task.id,
      answers: state.answers.map((item) => ({
        questionId: item.questionId,
        answer: String(item.answer || "").trim()
      }))
    };

    await fetchJson("/api/submissions", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload)
    });

    setStatus("Задание отправлено на проверку.", "status-pending");
  } catch (error) {
    setStatus(`Ошибка отправки: ${error.message}`, "status-error");
  } finally {
    submitStepBtn.disabled = false;
  }
});

async function init() {
  try {
    await loadTaskData();
    setStatus("", "status-none");
  } catch (error) {
    taskPageTitle.textContent = "Ошибка загрузки задания";
    taskPageMeta.textContent = "";
    taskPageInstruction.textContent = "";
    questionPrompt.textContent = "";
    questionInput.value = "";
    questionInput.disabled = true;
    prevStepBtn.disabled = true;
    nextStepBtn.disabled = true;
    submitStepBtn.disabled = true;
    setStatus(escapeHtml(error.message), "status-error");
  }
}

init();
