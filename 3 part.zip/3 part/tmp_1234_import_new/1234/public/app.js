﻿const state = {
  defaultStudentId: "student-001",
  studentId: null,
  submissionsByTask: {},
  mainProjectSelection: readSelectionFromUrl()
};

const taskGrid = document.getElementById("taskGrid");
const selectionNotice = document.getElementById("selectionNotice");

function readSelectionFromUrl() {
  const params = new URLSearchParams(window.location.search);

  return {
    studentId: params.get("studentId"),
    externalId: params.get("externalId"),
    externalIds: params.get("externalIds"),
    type: params.get("type"),
    subject: params.get("subject")
  };
}

function buildFeedQuery(studentId) {
  const query = new URLSearchParams({ studentId });
  const filters = state.mainProjectSelection;

  if (filters.externalId) query.set("externalId", filters.externalId);
  if (filters.externalIds) query.set("externalIds", filters.externalIds);
  if (filters.type) query.set("type", filters.type);
  if (filters.subject) query.set("subject", filters.subject);

  return query.toString();
}

function escapeHtml(value) {
  return String(value)
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#39;");
}

function renderSelectionNotice(selection) {
  if (!selection) {
    selectionNotice.hidden = true;
    selectionNotice.textContent = "";
    return;
  }

  const parts = [];

  if (Array.isArray(selection.externalIds) && selection.externalIds.length) {
    parts.push(`ID: ${selection.externalIds.join(", ")}`);
  }

  if (selection.type) {
    parts.push(`тип: ${selection.type}`);
  }

  if (selection.subject) {
    parts.push(`предмет: ${selection.subject}`);
  }

  if (!parts.length) {
    selectionNotice.hidden = true;
    selectionNotice.textContent = "";
    return;
  }

  selectionNotice.hidden = false;
  selectionNotice.textContent = `Выбранный в основном проекте фильтр: ${parts.join(" | ")}. Совпадений: ${selection.matchedTaskCount} из ${selection.sourceTaskCount}.`;
}

function levelClass(level) {
  if (level === "high") return "tag-level-high";
  if (level === "medium") return "tag-level-medium";
  return "tag-level-low";
}

function taskTypeLabel(type) {
  return type === "video" ? "Видео" : "Задание";
}

function formatDate(isoDate) {
  if (!isoDate) return "";
  const date = new Date(isoDate);
  if (Number.isNaN(date.getTime())) return "";

  return new Intl.DateTimeFormat("ru-RU", {
    dateStyle: "short",
    timeStyle: "short"
  }).format(date);
}

function getSubmissionStatusText(submission) {
  if (!submission) return "Решение не отправлено";

  const submittedAt = formatDate(submission.submittedAt);
  return submittedAt
    ? `Отправлено на проверку: ${submittedAt}`
    : "Решение отправлено на проверку";
}

function buildTaskPageUrl(taskId) {
  const backQuery = window.location.search || `?studentId=${encodeURIComponent(state.studentId)}`;
  const query = new URLSearchParams({
    studentId: state.studentId,
    taskId,
    back: backQuery
  });

  return `/task.html?${query.toString()}`;
}

function renderTasks(feed) {
  taskGrid.innerHTML = "";

  if (!feed.items.length) {
    taskGrid.innerHTML =
      "<p class='empty-state'>Нет заданий по текущему выбору в основном проекте.</p>";
    return;
  }

  feed.items.forEach((item) => {
    const card = document.createElement("article");
    const savedSubmission = state.submissionsByTask[item.id] || null;
    const statusText = getSubmissionStatusText(savedSubmission);
    const questionCount = Array.isArray(item.questions) ? item.questions.length : 0;

    card.className = "task-card";

    const supportsList = item.supports.length
      ? `<ul class=\"support-list\">${item.supports.map((text) => `<li>${escapeHtml(text)}</li>`).join("")}</ul>`
      : "<p class='task-details'>Дополнительная адаптация не требуется.</p>";

    card.innerHTML = `
      <div class="task-meta">
        <span class="tag tag-type-${escapeHtml(item.type)}">${taskTypeLabel(item.type)}</span>
        <span class="tag ${levelClass(item.adaptationLevel)}">Адаптация: ${escapeHtml(item.adaptationLevel)}</span>
      </div>
      <h3 class="task-title">${escapeHtml(item.title)}</h3>
      <p class="task-details">Предмет: ${escapeHtml(item.subject)} | Преподаватель: ${escapeHtml(item.teacher)}</p>
      <p class="task-details">Вопросов: ${questionCount} | Длительность: ${escapeHtml(item.estimatedDuration)} мин</p>
      ${supportsList}

      <a class="task-action task-link" href="${escapeHtml(buildTaskPageUrl(item.id))}">Открыть задание</a>
      <p class="submission-status ${savedSubmission ? "status-pending" : "status-none"}">${escapeHtml(statusText)}</p>
    `;

    taskGrid.appendChild(card);
  });
}

function applyDynamicUi(uiPreset) {
  document.documentElement.style.setProperty("--font-scale", uiPreset.fontScale);
  document.body.style.fontSize = `${16 * uiPreset.fontScale}px`;

  if (uiPreset.highContrast) {
    document.documentElement.classList.add("high-contrast");
  } else {
    document.documentElement.classList.remove("high-contrast");
  }

  if (uiPreset.largeControls) {
    document.documentElement.classList.add("large-controls");
  } else {
    document.documentElement.classList.remove("large-controls");
  }
}

async function fetchJson(url, options = {}) {
  const response = await fetch(url, options);

  if (!response.ok) {
    let message = "Request failed";
    const rawBody = await response.text();

    if (rawBody) {
      try {
        const json = JSON.parse(rawBody);
        message = json.error || message;
      } catch {
        message = rawBody;
      }
    }

    throw new Error(message);
  }

  return response.json();
}

async function loadSubmissions(studentId) {
  const data = await fetchJson(`/api/submissions?studentId=${encodeURIComponent(studentId)}`);
  const byTask = {};

  data.forEach((submission) => {
    if (!byTask[submission.taskId]) {
      byTask[submission.taskId] = submission;
    }
  });

  state.submissionsByTask = byTask;
}

async function loadAdaptedFeed(studentId) {
  const [feed] = await Promise.all([
    fetchJson(`/api/adapted-feed?${buildFeedQuery(studentId)}`),
    loadSubmissions(studentId)
  ]);

  renderSelectionNotice(feed.selection);
  renderTasks(feed);
  applyDynamicUi(feed.uiPreset);
}

async function init() {
  try {
    state.studentId = state.mainProjectSelection.studentId || state.defaultStudentId;
    await loadAdaptedFeed(state.studentId);
  } catch (error) {
    taskGrid.innerHTML = `<p class='empty-state'>Не удалось загрузить данные: ${escapeHtml(error.message)}</p>`;
  }
}

init();
