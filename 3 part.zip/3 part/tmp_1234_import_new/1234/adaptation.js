﻿const ADAPTATION_LEVELS = {
  low: 1,
  medium: 2,
  high: 3
};

function normalizeLevel(value) {
  if (!value) return ADAPTATION_LEVELS.low;
  return ADAPTATION_LEVELS[value] || ADAPTATION_LEVELS.low;
}

function toReadableMode(level) {
  if (level >= ADAPTATION_LEVELS.high) return "high";
  if (level >= ADAPTATION_LEVELS.medium) return "medium";
  return "low";
}

function simplifyInstruction(instruction) {
  return String(instruction || "")
    .replace(/\s+/g, " ")
    .replace(/,\s*/g, ". ")
    .replace(/\.\s+/g, ". ")
    .trim();
}

function normalizeQuestions(task, simplified) {
  const source = Array.isArray(task.questions) ? task.questions : [];
  const questions = source
    .map((question, index) => {
      const prompt = simplifyInstruction(question?.prompt || question?.text || "");
      if (!prompt) return null;

      return {
        id: String(question.id || `q${index + 1}`),
        prompt: simplified ? prompt : String(question.prompt || question.text).trim(),
        placeholder: String(question.placeholder || "Введите ответ").trim(),
        required: question.required !== false
      };
    })
    .filter(Boolean);

  if (questions.length) return questions;

  const fallbackPrompt = simplifyInstruction(task.instructions || "Опиши решение задания.");
  return [
    {
      id: "q1",
      prompt: fallbackPrompt,
      placeholder: "Введите ответ",
      required: true
    }
  ];
}

function buildUiPreset(profile) {
  const supportNeeds = profile.supportNeeds || {};
  const preferences = profile.preferences || {};
  const visionLevel = normalizeLevel(supportNeeds.vision);
  const motorLevel = normalizeLevel(supportNeeds.motor);

  const fontScale =
    visionLevel >= ADAPTATION_LEVELS.high ? 1.25 : visionLevel >= ADAPTATION_LEVELS.medium ? 1.1 : 1;
  const highContrast = Boolean(preferences.highContrast || visionLevel >= ADAPTATION_LEVELS.high);
  const largeControls = motorLevel >= ADAPTATION_LEVELS.medium;

  return {
    fontScale,
    highContrast,
    largeControls,
    spacing: largeControls ? "expanded" : "standard"
  };
}

function adaptTask(task, profile) {
  const supportNeeds = profile.supportNeeds || {};
  const preferences = profile.preferences || {};

  const hearingLevel = normalizeLevel(supportNeeds.hearing);
  const speechLevel = normalizeLevel(supportNeeds.speech);
  const motorLevel = normalizeLevel(supportNeeds.motor);
  const cognitiveLevel = normalizeLevel(supportNeeds.cognitive);

  const sourceLanguage = task.language || "ru";
  const translations = Array.isArray(task.translations) ? task.translations : [];
  const sourceDuration = Number(task.durationMinutes) || 20;
  const sourceInstruction = task.instructions || "Открой материал и выполни задание.";

  const supports = [];
  const media = {
    subtitles: false,
    signLanguage: false,
    transcript: false,
    voiceOver: false
  };

  let interactionMode = "standard";
  let complexityMode = "standard";
  let durationMultiplier = 1;
  let instructionText = sourceInstruction;

  if ((task.type || "assignment") === "video" && hearingLevel >= ADAPTATION_LEVELS.medium) {
    media.subtitles = true;
    media.transcript = true;
    supports.push("Включены субтитры и текстовая расшифровка");
  }

  if (hearingLevel >= ADAPTATION_LEVELS.high) {
    media.signLanguage = true;
    supports.push("Добавлены визуальные подсказки жестового сопровождения");
  }

  if (speechLevel >= ADAPTATION_LEVELS.medium || cognitiveLevel >= ADAPTATION_LEVELS.medium) {
    complexityMode = "simplified";
    instructionText = simplifyInstruction(sourceInstruction);
    supports.push("Инструкция упрощена и разбита на короткие шаги");
  }

  if (motorLevel >= ADAPTATION_LEVELS.medium) {
    interactionMode = "large-targets";
    durationMultiplier += 0.25;
    supports.push("Увеличены элементы управления");
  }

  if (cognitiveLevel >= ADAPTATION_LEVELS.high) {
    durationMultiplier += 0.25;
    supports.push("Увеличено время выполнения задания");
  }

  if (preferences.voiceAssistant) {
    media.voiceOver = true;
    supports.push("Включено голосовое сопровождение");
  }

  if (profile.language !== sourceLanguage && translations.includes(profile.language)) {
    supports.push(`Материал переведен на язык: ${String(profile.language || "ru").toUpperCase()}`);
  }

  return {
    id: task.id || `task-${Date.now().toString(36)}`,
    sourceTaskId: task.externalId || null,
    type: task.type || "assignment",
    subject: task.subject || "Общий курс",
    teacher: task.teacher || "Не указан",
    title: task.title || "Учебный материал",
    language: profile.language || "ru",
    complexityMode,
    instructionText,
    questions: normalizeQuestions(task, complexityMode === "simplified"),
    interactionMode,
    adaptationLevel: toReadableMode(Math.max(hearingLevel, speechLevel, motorLevel, cognitiveLevel)),
    estimatedDuration: Math.ceil(sourceDuration * durationMultiplier),
    dueDate: task.dueDate || null,
    media,
    supports,
    original: {
      durationMinutes: sourceDuration,
      language: sourceLanguage
    }
  };
}

function adaptFeed(tasks, profile) {
  const safeTasks = Array.isArray(tasks) ? tasks : [];
  const safeProfile = profile || {
    id: "student-unknown",
    fullName: "Unknown",
    grade: "-",
    language: "ru",
    supportNeeds: {},
    preferences: {}
  };

  const uiPreset = buildUiPreset(safeProfile);
  const adaptedItems = safeTasks.map((task) => adaptTask(task || {}, safeProfile));

  return {
    student: {
      id: safeProfile.id,
      fullName: safeProfile.fullName,
      grade: safeProfile.grade,
      language: safeProfile.language
    },
    uiPreset,
    generatedAt: new Date().toISOString(),
    items: adaptedItems
  };
}

module.exports = {
  adaptFeed
};
