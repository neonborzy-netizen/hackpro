document.addEventListener("DOMContentLoaded", () => {
  window.speechSynthesis.getVoices();
  window.speechSynthesis.onvoiceschanged = () => window.speechSynthesis.getVoices();

  function getVoice() {
    const voiceSelect = document.getElementById("ttsVoiceSelect");
    if (voiceSelect && voiceSelect.value !== "auto") {
      const voices = window.speechSynthesis.getVoices();
      return voices.find((v) => v.name === voiceSelect.value) || null;
    }
    // Автоматический выбор
    const voices = window.speechSynthesis.getVoices();
    return voices.find((v) => v.lang.startsWith("kk")) || voices.find((v) => v.lang.startsWith("ru")) || null;
  }

  function getSpeed() {
    const speedSlider = document.getElementById("ttsSpeedSlider");
    return speedSlider ? parseFloat(speedSlider.value) : 0.9;
  }

  function speak(text) {
    window.speechSynthesis.cancel();
    const utterance = new SpeechSynthesisUtterance(text);
    utterance.lang = "kk-KZ";
    utterance.rate = getSpeed();
    const voice = getVoice();
    if (voice) utterance.voice = voice;
    window.speechSynthesis.speak(utterance);
  }

  window.speakAssistantReply = function (text) {
    const assistantToggle = document.getElementById("assistantToggle");
    if (assistantToggle && !assistantToggle.checked) return;
    if (!text || typeof text !== "string") return;
    speak(text);
  };

  const assistantToggle = document.getElementById("assistantToggle");
  if (assistantToggle) {
    function updateAssistantState() {
      document.body.classList.toggle("assistant-off", !assistantToggle.checked);
    }
    assistantToggle.addEventListener("change", updateAssistantState);
    updateAssistantState();
  }
});
