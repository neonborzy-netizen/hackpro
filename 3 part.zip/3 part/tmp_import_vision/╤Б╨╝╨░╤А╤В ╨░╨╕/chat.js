document.addEventListener('DOMContentLoaded', () => {
  const OPENROUTER_URL = 'https://openrouter.ai/api/v1/chat/completions';
  const OPENROUTER_API_KEY = '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';
  const MAX_BOOK_CHARS = 28000;
  // Модель GPT-4.5 Mini (требует кредиты на OpenRouter)
  const OPENROUTER_MODEL = 'openai/gpt-4o-mini';

  const toggleBtn = document.getElementById('assistantChatToggle');
  const panel = document.getElementById('assistantChatPanel');
  const closeBtn = document.getElementById('assistantChatClose');
  const messagesEl = document.getElementById('assistantChatMessages');
  const inputEl = document.getElementById('assistantChatInput');
  const sendBtn = document.getElementById('assistantChatSend');

  if (!toggleBtn || !panel || !messagesEl || !inputEl || !sendBtn) return;

  let chatHistory = [];

  function appendMessage(role, text, isError) {
    const div = document.createElement('div');
    div.className = 'assistant-chat-msg ' + (isError ? 'error' : role);
    div.textContent = text;
    messagesEl.appendChild(div);
    messagesEl.scrollTop = messagesEl.scrollHeight;
  }

  function setLoading(loading) {
    sendBtn.disabled = loading;
    sendBtn.textContent = loading ? '…' : 'Отпр.';
  }

  function extractReply(data) {
    const msg = data.choices && data.choices[0] && data.choices[0].message;
    if (!msg) return '';
    const content = msg.content;
    if (typeof content === 'string') return content.trim();
    if (Array.isArray(content)) {
      const part = content.find((p) => p && (p.text !== undefined));
      return part && typeof part.text === 'string' ? part.text.trim() : '';
    }
    return '';
  }

  closeBtn?.addEventListener('click', () => { panel.hidden = true; });

  toggleBtn.addEventListener('click', () => {
    const wasHidden = panel.hidden;
    panel.hidden = !wasHidden;
    if (wasHidden) inputEl.focus();
  });

  sendBtn.addEventListener('click', sendMessage);
  inputEl.addEventListener('keydown', (e) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      sendMessage();
    }
  });

  function sendMessage() {
    const text = inputEl.value.trim();
    if (!text) return;

    const bookText = typeof window.currentBookText === 'string' ? window.currentBookText : '';
    if (!bookText) {
      appendMessage('assistant', 'Загрузите PDF-книгу, чтобы задавать вопросы по её содержанию.', true);
      return;
    }

    inputEl.value = '';
    chatHistory.push({ role: 'user', content: text });
    appendMessage('user', text);

    const truncatedBook = bookText.length > MAX_BOOK_CHARS
      ? bookText.slice(0, MAX_BOOK_CHARS) + '\n\n[... текст обрезан ...]'
      : bookText;

    const systemContent =
      'Ты — виртуальный помощник по загруженной книге. Отвечай только на основе приведённого ниже текста книги. Если ответа в тексте нет, так и скажи. Отвечай кратко и по делу, на казахском языке (қазақша).\n\n--- Текст книги ---\n\n' + truncatedBook;

    const messages = [
      { role: 'system', content: systemContent },
      ...chatHistory.map((m) => ({ role: m.role, content: m.content }))
    ];

    setLoading(true);

    const headers = {
      'Content-Type': 'application/json',
      'Authorization': 'Bearer ' + OPENROUTER_API_KEY
    };
    if (window.location.origin && window.location.origin !== 'null') {
      headers['HTTP-Referer'] = window.location.origin;
    }
    fetch(OPENROUTER_URL, {
      method: 'POST',
      headers,
      body: JSON.stringify({
        model: OPENROUTER_MODEL,
        messages,
        max_tokens: 1024,
        temperature: 0.4
      })
    })
      .then(async (res) => {
        let json;
        try {
          json = await res.json();
        } catch (_) {
          throw new Error('Ответ сервера не JSON. Код: ' + res.status);
        }
        if (!res.ok) {
          const errMsg = (json && (json.error && json.error.message)) ? json.error.message : (res.status + ' ' + res.statusText);
          throw new Error(errMsg);
        }
        return json;
      })
      .then((data) => {
        const reply = extractReply(data) || 'Нет ответа.';
        chatHistory.push({ role: 'assistant', content: reply });
        appendMessage('assistant', reply);
        if (typeof window.speakAssistantReply === 'function') {
          window.speakAssistantReply(reply);
        }
      })
      .catch((err) => {
        let msg = err && err.message ? err.message : String(err);
        if (msg.includes('Failed to fetch') || msg.includes('NetworkError') || msg.includes('Load failed')) {
          msg = 'Нет связи с сервером. Откройте сайт через локальный сервер (не как file://), например: Live Server или npx serve.';
        }
        appendMessage('assistant', msg, true);
      })
      .finally(() => {
        setLoading(false);
      });
  }
});
