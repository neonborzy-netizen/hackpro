document.addEventListener('DOMContentLoaded', () => {
    const aiToggle = document.getElementById('aiMonitorToggle');
    const notify = document.getElementById('aiNotify');
    let timer;

    aiToggle.addEventListener('change', () => {
        if (aiToggle.checked) {
            timer = setTimeout(() => {
                if (aiToggle.checked) notify.style.display = 'block';
            }, 1200000); 
        } else {
            clearTimeout(timer);
            notify.style.display = 'none';
        }
    });
});