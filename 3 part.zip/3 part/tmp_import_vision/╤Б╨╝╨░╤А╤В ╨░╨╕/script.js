document.addEventListener('DOMContentLoaded', () => {
    const root = document.documentElement;

    // Размер текста
    const slider = document.getElementById('textSizeSlider');
    const display = document.getElementById('textSizeDisplay');
    if (slider && display) {
        slider.addEventListener('input', (e) => {
            const v = e.target.value;
            root.style.setProperty('--font-scale', v);
            display.textContent = Math.round(v * 100) + '%';
        });
    }

    // Шрифт
    document.querySelectorAll('.font-option').forEach((btn) => {
        btn.addEventListener('click', () => {
            document.querySelectorAll('.font-option').forEach((b) => b.classList.remove('active'));
            btn.classList.add('active');
            root.style.setProperty('--main-font', btn.getAttribute('data-font'));
        });
    });

    // Контрастность — исправлен setTheme (без event.target)
    function setTheme(t, btn) {
        document.body.classList.remove('theme-bw', 'theme-wb', 'theme-yb');
        document.querySelectorAll('.contrast-btn').forEach(b => b.classList.remove('active'));
        if (t !== 'std') document.body.classList.add('theme-' + t);
        if (btn) btn.classList.add('active');
    }
    document.querySelectorAll('.contrast-btn[data-theme]').forEach((btn) => {
        btn.addEventListener('click', () => setTheme(btn.getAttribute('data-theme'), btn));
    });
    window.setTheme = setTheme; // на случай если вызывается извне

    // Кнопка «Назад»
    const backBtn = document.getElementById('backBtn');
    if (backBtn) {
        backBtn.addEventListener('click', () => {
            if (window.history.length > 1) {
                window.history.back();
            } else {
                window.location.href = '/';
            }
        });
    }

    // Hover-zoom (супер-курсор в scursor.js)
    const hoverZoomToggle = document.getElementById('hoverZoomToggle');
    if (hoverZoomToggle) {
        hoverZoomToggle.addEventListener('change', (e) => {
            document.body.classList.toggle('hover-zoom', e.target.checked);
        });
    }

    // TTS — озвучка текста и картинок
    const synth = window.speechSynthesis;
    const ttsToggle = document.getElementById('ttsToggle');
    const ttsSettings = document.getElementById('ttsSettings');
    const ttsSpeedSlider = document.getElementById('ttsSpeedSlider');
    const ttsSpeedDisplay = document.getElementById('ttsSpeedDisplay');
    const ttsVoiceSelect = document.getElementById('ttsVoiceSelect');
    const TTS_LANG = 'kk-KZ';

    // Загрузка настроек из localStorage
    function loadTTSSettings() {
        const savedSpeed = localStorage.getItem('ttsSpeed');
        const savedVoice = localStorage.getItem('ttsVoice');
        if (savedSpeed) {
            ttsSpeedSlider.value = savedSpeed;
            updateSpeedDisplay();
        }
        if (savedVoice && savedVoice !== 'auto') {
            ttsVoiceSelect.value = savedVoice;
        }
    }

    // Сохранение настроек в localStorage
    function saveTTSSettings() {
        localStorage.setItem('ttsSpeed', ttsSpeedSlider.value);
        localStorage.setItem('ttsVoice', ttsVoiceSelect.value);
    }

    // Обновление отображения скорости
    function updateSpeedDisplay() {
        const speed = parseFloat(ttsSpeedSlider.value);
        ttsSpeedDisplay.textContent = speed.toFixed(1) + 'x';
    }

    // Заполнение списка голосов
    function populateVoices() {
        const voices = synth.getVoices();
        const currentValue = ttsVoiceSelect.value;
        
        // Очистка опций кроме "Автоматический"
        ttsVoiceSelect.innerHTML = '<option value="auto">Автоматический</option>';
        
        // Группировка голосов по языкам
        const voiceGroups = {};
        voices.forEach(voice => {
            if (voice.lang.startsWith('kk') || voice.lang.startsWith('ru') || voice.lang.startsWith('en')) {
                const lang = voice.lang.split('-')[0];
                if (!voiceGroups[lang]) voiceGroups[lang] = [];
                voiceGroups[lang].push(voice);
            }
        });

        // Добавление голосов в селект
        Object.keys(voiceGroups).sort().forEach(lang => {
            const optgroup = document.createElement('optgroup');
            optgroup.label = lang === 'kk' ? 'Казахский' : lang === 'ru' ? 'Русский' : 'Английский';
            
            voiceGroups[lang].forEach(voice => {
                const option = document.createElement('option');
                option.value = voice.name;
                const gender = voice.name.toLowerCase().includes('female') || voice.name.toLowerCase().includes('женск') 
                    ? ' (женский)' 
                    : voice.name.toLowerCase().includes('male') || voice.name.toLowerCase().includes('мужск')
                    ? ' (мужской)'
                    : '';
                option.textContent = voice.name + gender;
                optgroup.appendChild(option);
            });
            
            ttsVoiceSelect.appendChild(optgroup);
        });

        // Восстановление выбранного значения
        if (currentValue && currentValue !== 'auto') {
            ttsVoiceSelect.value = currentValue;
        }
    }

    // Получение выбранного голоса
    function getSelectedVoice() {
        if (ttsVoiceSelect.value === 'auto') {
            const voices = synth.getVoices();
            return voices.find(v => v.lang.startsWith('kk')) ||
                   voices.find(v => v.lang.startsWith('ru')) ||
                   null;
        } else {
            const voices = synth.getVoices();
            return voices.find(v => v.name === ttsVoiceSelect.value) || null;
        }
    }

    function createUtterance(text, lang) {
        const ut = new SpeechSynthesisUtterance(text);
        ut.lang = lang || TTS_LANG;
        ut.rate = parseFloat(ttsSpeedSlider.value);
        const voice = getSelectedVoice();
        if (voice) ut.voice = voice;
        return ut;
    }

    // Обработчики событий
    if (ttsToggle && ttsSettings) {
        ttsToggle.addEventListener('change', (e) => {
            ttsSettings.style.display = e.target.checked ? 'block' : 'none';
        });
        // Показываем настройки если TTS включен
        if (ttsToggle.checked) {
            ttsSettings.style.display = 'block';
        }
    }

    if (ttsSpeedSlider && ttsSpeedDisplay) {
        ttsSpeedSlider.addEventListener('input', () => {
            updateSpeedDisplay();
            saveTTSSettings();
        });
        updateSpeedDisplay();
    }

    if (ttsVoiceSelect) {
        ttsVoiceSelect.addEventListener('change', () => {
            saveTTSSettings();
        });
    }

    // Инициализация голосов
    synth.getVoices();
    window.speechSynthesis.onvoiceschanged = () => {
        synth.getVoices();
        populateVoices();
    };
    
    // Загрузка настроек при загрузке страницы
    loadTTSSettings();
    // Попытка заполнить голоса сразу и после загрузки
    setTimeout(populateVoices, 100);

    function speakText(text) {
        if (!text || !ttsToggle?.checked) return;
        synth.cancel();
        synth.speak(createUtterance(text, TTS_LANG));
    }

    function speakImageDescription(altText) {
        if (!ttsToggle?.checked) return;
        synth.cancel();
        const text = altText && altText.trim() ? altText.trim() : 'Сурет сипаттамасы жоқ';
        synth.speak(createUtterance(text, TTS_LANG));
    }

    document.body.addEventListener('mouseover', (e) => {
        if (!ttsToggle || !ttsToggle.checked) return;
        const target = e.target;

        // Текст: P, H1, H2, LI, .formula
        if (['P', 'H1', 'H2', 'LI'].includes(target.tagName) || target.classList.contains('formula')) {
            speakText(target.innerText);
            return;
        }

        // Картинки
        if (target.tagName === 'IMG') {
            const alt = target.getAttribute('alt');
            const assistant = target.getAttribute('data-assistant');
            const desc = (alt && alt.trim()) || (assistant && assistant.trim()) || null;
            speakImageDescription(desc);
            return;
        }

        // Элементы с data-assistant (кнопки, подсказки, в т.ч. вложенные)
        const assistant = target.closest('[data-assistant]');
        if (assistant) {
            const text = assistant.getAttribute('data-assistant');
            if (text && text.trim()) speakText(text.trim());
        }
    });

    synth.getVoices();
    window.speechSynthesis.onvoiceschanged = () => synth.getVoices();
});
