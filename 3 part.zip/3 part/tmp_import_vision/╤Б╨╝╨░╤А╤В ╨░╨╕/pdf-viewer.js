/* global pdfjsLib, Tesseract */

document.addEventListener('DOMContentLoaded', () => {
    pdfjsLib.GlobalWorkerOptions.workerSrc = 'https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.11.174/pdf.worker.min.js';

    const importZone = document.getElementById('pdfImportZone');
    const pdfViewer = document.getElementById('pdfViewer');
    const pdfFileInput = document.getElementById('pdfFileInput');
    if (!importZone || !pdfViewer || !pdfFileInput) return;

    const pdfSelectBtn = document.getElementById('pdfSelectBtn');
    const pdfPages = document.getElementById('pdfPages');
    const pdfToolbar = document.querySelector('.pdf-toolbar');
    const pdfPrevPage = document.getElementById('pdfPrevPage');
    const pdfNextPage = document.getElementById('pdfNextPage');
    const pdfPageInfo = document.getElementById('pdfPageInfo');
    const pdfCloseBtn = document.getElementById('pdfCloseBtn');
    const pdfFilename = document.getElementById('pdfFilename');

    let pdfDoc = null;
    let currentPage = 1;
    let totalPages = 0;
    let currentFilename = '';
    let allPageTexts = [];
    let ocrProgress = null;

    function preprocessImageForOCR(canvas) {
        const ctx = canvas.getContext('2d');
        const imageData = ctx.getImageData(0, 0, canvas.width, canvas.height);
        const data = imageData.data;

        for (let i = 0; i < data.length; i += 4) {
            const gray = data[i] * 0.299 + data[i + 1] * 0.587 + data[i + 2] * 0.114;
            const contrast = 1.4;
            const adjusted = ((gray / 255 - 0.5) * contrast + 0.5) * 255;
            const value = Math.max(0, Math.min(255, adjusted));
            data[i] = value;
            data[i + 1] = value;
            data[i + 2] = value;
        }

        ctx.putImageData(imageData, 0, 0);
        return canvas;
    }

    async function extractTextFromImage(page) {
        let canvas = null;
        try {
            const viewport = page.getViewport({ scale: 3.0 });
            canvas = document.createElement('canvas');
            const context = canvas.getContext('2d');
            canvas.height = viewport.height;
            canvas.width = viewport.width;

            await page.render({
                canvasContext: context,
                viewport
            }).promise;

            const processedCanvas = preprocessImageForOCR(canvas);
            const result = await Tesseract.recognize(processedCanvas, 'kaz+rus+eng', {
                logger: (m) => {
                    if (m.status === 'recognizing text' && ocrProgress) {
                        ocrProgress.textContent = `OCR: ${Math.round(m.progress * 100)}%`;
                    }
                },
                tessedit_pageseg_mode: Tesseract.PSM.AUTO,
                preserve_interword_spaces: '1'
            });

            return (result?.data?.text || '').trim();
        } catch (error) {
            console.warn('OCR failed for page:', error);
            if (!canvas) return '';
            try {
                const fallbackResult = await Tesseract.recognize(canvas, 'rus+eng', {
                    tessedit_pageseg_mode: Tesseract.PSM.AUTO,
                    preserve_interword_spaces: '1'
                });
                return (fallbackResult?.data?.text || '').trim();
            } catch (fallbackError) {
                console.warn('Fallback OCR also failed:', fallbackError);
                return '';
            }
        }
    }

    const BOILERPLATE_PATTERNS = [
        /^.*учебники\s+Казахстана.*OKULYK/i,
        /^.*OKULYK\.(COM|KZ).*$/i,
        /^\*?\s*Книга предоставлена исключительно в образовательных целях\s*$/i,
        /^согласно Приказа Министра образования и науки.*Казахстан/i
    ];

    const ARTIFACT_PATTERNS = [
        /^[A-Za-z]:\\(?:[^\\\r\n]+\\)*[^\\\r\n]+\.(?:tif|tiff|png|jpe?g)\s*(?:[_-]page\s*\d+|page\s*\d+)?$/i,
        /^.*\.(?:tif|tiff|png|jpe?g)\s*(?:[_-]page\s*\d+|page\s*\d+)\s*$/i
    ];

    function filterBoilerplate(text) {
        if (!text || typeof text !== 'string') return text;
        return text
            .split(/\n+/)
            .map(s => s.trim())
            .filter(Boolean)
            .filter(line => !ARTIFACT_PATTERNS.some(p => p.test(line)))
            .filter(line => !BOILERPLATE_PATTERNS.some(p => p.test(line)))
            .join('\n')
            .trim();
    }

    async function pageContainsImages(page) {
        try {
            const opList = await page.getOperatorList();
            const OPS = pdfjsLib.OPS;
            return opList.fnArray.some(fn =>
                fn === OPS.paintImageXObject ||
                fn === OPS.paintInlineImageXObject ||
                fn === OPS.paintImageMaskXObject
            );
        } catch (error) {
            console.warn('Failed to inspect page operators:', error);
            return false;
        }
    }

    function mergePageTexts(primaryText, ocrText) {
        const left = (primaryText || '').trim();
        const right = (ocrText || '').trim();
        if (!right) return left;
        if (!left) return right;

        const seen = new Set();
        const merged = [];

        const addUniqueLines = (text) => {
            text
                .split(/\n+/)
                .map(s => s.trim())
                .filter(Boolean)
                .forEach(line => {
                    const key = line.toLowerCase();
                    if (seen.has(key)) return;
                    seen.add(key);
                    merged.push(line);
                });
        };

        addUniqueLines(left);
        addUniqueLines(right);
        return merged.join('\n');
    }

    function showImportZone() {
        importZone.style.display = 'flex';
        pdfViewer.style.display = 'none';
        pdfDoc = null;
        allPageTexts = [];
        window.currentBookText = '';
    }

    function showViewer() {
        importZone.style.display = 'none';
        pdfViewer.style.display = 'block';
        pdfFilename.textContent = currentFilename;
    }

    function buildTextContent() {
        pdfPages.innerHTML = '';
        allPageTexts.forEach((pageText, index) => {
            const pageNum = index + 1;
            const section = document.createElement('section');
            section.className = 'pdf-text-page';
            section.setAttribute('data-assistant', `Страница ${pageNum} из ${totalPages}. ${pageText.trim().slice(0, 200)}`);

            const heading = document.createElement('h2');
            heading.className = 'pdf-page-heading';
            heading.textContent = `Страница ${pageNum}`;
            heading.setAttribute('data-assistant', `Страница ${pageNum}`);

            const content = document.createElement('div');
            content.className = 'pdf-text-content';

            const lines = pageText.split(/\n+/).filter(s => s.trim());
            lines.forEach(line => {
                const p = document.createElement('p');
                p.textContent = line.trim();
                p.setAttribute('data-assistant', line.trim());
                content.appendChild(p);
            });

            if (lines.length === 0) {
                const p = document.createElement('p');
                p.textContent = '(На этой странице нет извлекаемого текста)';
                p.setAttribute('data-assistant', 'На этой странице нет извлекаемого текста');
                content.appendChild(p);
            }

            section.appendChild(heading);
            section.appendChild(content);
            pdfPages.appendChild(section);
        });

        pdfPageInfo.textContent = `1 / ${totalPages}`;
        currentPage = 1;
        pdfPrevPage.disabled = true;
        pdfNextPage.disabled = totalPages <= 1;
    }

    function showPage(num) {
        const sections = pdfPages.querySelectorAll('.pdf-text-page');
        sections.forEach((s, i) => {
            s.style.display = i + 1 === num ? 'block' : 'none';
        });
        pdfPageInfo.textContent = `${num} / ${totalPages}`;
        currentPage = num;
        pdfPrevPage.disabled = num <= 1;
        pdfNextPage.disabled = num >= totalPages;
        pdfPages.scrollTop = 0;
    }

    async function loadPDF(file) {
        const arrayBuffer = await file.arrayBuffer();
        pdfDoc = await pdfjsLib.getDocument(arrayBuffer).promise;
        totalPages = pdfDoc.numPages;
        currentFilename = file.name;
        allPageTexts = [];

        const progressDiv = document.createElement('div');
        progressDiv.style.cssText = 'position: fixed; top: 50%; left: 50%; transform: translate(-50%, -50%); background: white; padding: 20px; border-radius: 10px; box-shadow: 0 4px 20px rgba(0,0,0,0.3); z-index: 10000; text-align: center;';
        progressDiv.innerHTML = '<h3>Обработка PDF...</h3><p id="ocrProgress">Извлечение текста...</p>';
        document.body.appendChild(progressDiv);
        ocrProgress = document.getElementById('ocrProgress');

        for (let i = 1; i <= totalPages; i++) {
            ocrProgress.textContent = `Страница ${i} из ${totalPages}: извлечение текста...`;

            const page = await pdfDoc.getPage(i);
            const textContent = await page.getTextContent();
            const lines = [];
            let line = [];

            textContent.items.forEach(item => {
                line.push(item.str);
                if (item.hasEOL) {
                    lines.push(line.join('').trim());
                    line = [];
                }
            });

            if (line.length) lines.push(line.join('').trim());
            let pageTextRaw = lines.join('\n');

            const hasImages = await pageContainsImages(page);
            const textLength = pageTextRaw.replace(/\s+/g, '').length;
            if (textLength < 50 || hasImages) {
                ocrProgress.textContent = hasImages
                    ? `Страница ${i} из ${totalPages}: OCR (текст на изображениях)...`
                    : `Страница ${i} из ${totalPages}: OCR распознавание...`;

                const ocrText = await extractTextFromImage(page);
                if (ocrText) {
                    pageTextRaw = textLength < 50
                        ? (ocrText.length > textLength ? ocrText : pageTextRaw)
                        : mergePageTexts(pageTextRaw, ocrText);
                }
            }

            allPageTexts.push(filterBoilerplate(pageTextRaw) || pageTextRaw);
        }

        document.body.removeChild(progressDiv);
        ocrProgress = null;

        showViewer();
        buildTextContent();
        window.currentBookText = allPageTexts.join('\n\n');

        if (totalPages > 1) {
            pdfToolbar.style.display = '';
            showPage(1);
        } else {
            pdfToolbar.style.display = 'none';
        }
    }

    pdfSelectBtn.addEventListener('click', () => pdfFileInput.click());
    pdfFileInput.addEventListener('change', (e) => {
        const file = e.target.files[0];
        if (file && file.type === 'application/pdf') loadPDF(file);
        e.target.value = '';
    });

    importZone.addEventListener('dragover', (e) => {
        e.preventDefault();
        importZone.classList.add('pdf-drag-over');
    });

    importZone.addEventListener('dragleave', () => {
        importZone.classList.remove('pdf-drag-over');
    });

    importZone.addEventListener('drop', (e) => {
        e.preventDefault();
        importZone.classList.remove('pdf-drag-over');
        const file = e.dataTransfer.files[0];
        if (file && file.type === 'application/pdf') loadPDF(file);
    });

    importZone.addEventListener('click', (e) => {
        if (e.target === importZone || e.target.closest('.pdf-import-inner')) {
            if (!e.target.closest('.pdf-import-btn')) pdfFileInput.click();
        }
    });

    pdfPrevPage.addEventListener('click', () => {
        if (currentPage > 1) showPage(currentPage - 1);
    });

    pdfNextPage.addEventListener('click', () => {
        if (currentPage < totalPages) showPage(currentPage + 1);
    });

    pdfCloseBtn.addEventListener('click', showImportZone);
});
